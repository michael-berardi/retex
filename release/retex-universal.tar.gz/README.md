# Retex

<p align="center">
  <strong>A local-first Markdown vault engine and machine-readable CLI for people and agents.</strong><br />
  <a href="#install-and-run">Install</a> ·
  <a href="#cli">CLI</a> ·
  <a href="#mcp-server">MCP</a> ·
  <a href="#encrypted-sync">Encrypted sync</a> ·
  <a href="#updates">Updates</a>
</p>

Retex is a local-first Markdown vault architecture: your vault is an ordinary
folder of Markdown files with YAML front matter, and Retex gives it a fast
query surface — search, boards, saved views, undo, watching, and an MCP
server — without ever locking your files in a database.

Retex is intentionally headless. There is no bundled reader UI; the vault
format and the CLI are the product, and any future reader consumes the same
`RetexCore` package. No account system, analytics, remote database, or
third-party runtime dependency.

## Features

- Navigate and query multiple Markdown vaults from one CLI.
- Search titles, bodies, properties, and labels.
- Edit notes with atomic writes while preserving unknown YAML properties.
- Create, filter, rank, move, and archive Kanban cards without deleting files.
- Undo any mutation (`retex undo`), inspect history (`retex log`).
- Watch vaults for external changes (`retex watch`).
- Custom board columns and named saved views per vault.
- Drive a vault directly from any MCP host with the built-in MCP server.
- Encrypted vault export/import for sync by any channel.
- Self-update with checksum verification and rollback.

## Requirements

- macOS 14 or later.
- A Swift 6.0 toolchain to build from source (Xcode 16 or later).
- `RetexCore` also compiles for iOS 17 for future vault reader apps.

## Install and run

Build from source with Swift Package Manager:

```bash
git clone https://github.com/michael-berardi/retex.git
cd retex
swift build
.build/debug/retex --help
```

Or grab a signed release binary from the
[Releases](https://github.com/michael-berardi/retex/releases) page and put it
on your `PATH`. Every release asset ships with a SHA-256 checksum file.

## CLI

```bash
retex list --vault ~/Documents/CRM --type deal --json
retex search "website rebuild" --vault ~/Documents/CRM --json
retex create --vault ./CRM --type deal --title "Acme redesign" --status Inbox --set owner=Sam --json
retex set ./CRM/Deals/acme-redesign.md due=2026-08-01 'next_action=Send scope' --json
retex move ./CRM/Deals/acme-redesign.md Proposal --rank 3 --json
retex board --vault ./CRM --view pipeline --json
```

Commands: `list`, `search`, `show`, `create`, `set`, `move`, `archive`,
`board`, `views`, `schema`, `undo`, `log`, `doctor`, `watch`, `mcp`,
`export`, `import`, `update`, `version`. Run `retex schema` for the record
types, core properties, and board statuses understood by the current build.

### JSON output

Successful JSON responses use this envelope (`schema_version` is bumped when
the contract changes):

```json
{
  "ok": true,
  "schema_version": 1,
  "data": {}
}
```

With `--json`, invalid arguments exit with code 64 and file or storage
failures exit with code 74. Failures use the same machine-readable contract
with the same `schema_version` field.

Exit codes: `0` success, `64` invalid usage, `74` file or storage failure.

### Undo, views, and doctor

- **Undo** — every mutation records the file's previous content in
  `<vault>/.retex/history.jsonl` (capped at 50 entries per file, so total
  journal size scales with how many distinct files a vault touches).
  Cross-process safe: an MCP server and CLI runs against one vault serialize
  their journal writes through an advisory lock. `retex undo <file>` restores
  it; `retex log <file>` lists the journal.
- **Saved views** — `<vault>/.retex/config.json` can define custom board
  columns and named views:

```json
{
  "columns": [{ "title": "Backlog", "statuses": ["Inbox", "New"] }],
  "views": [{ "name": "pipeline", "type": "deal", "status": "Proposal" }]
}
```

Use them with `retex board --view pipeline`, list with `retex views`, and
validate a vault's structure, config, and journal with `retex doctor`.

### Watching

`retex watch --vault ./CRM` streams change batches until Ctrl-C. With
`--json`, each batch is one line: `{"changed":["Notes/foo.md", ...]}`.
Internal `.retex/` state never appears in the stream.

## MCP server

Retex ships a zero-dependency MCP (Model Context Protocol) server so any MCP
host can drive a vault directly over stdio:

```bash
retex mcp --vault ./CRM
```

Tools: `list_notes`, `search_notes`, `read_note`, `create_note`,
`set_property`, `move_card`, `archive_note`, and `get_board`. Responses use
newline-delimited JSON-RPC 2.0 (per the MCP stdio transport spec);
diagnostics go to stderr only.

Example host configuration (placeholders, no credentials):

```json
{
  "mcpServers": {
    "retex": {
      "command": "/usr/local/bin/retex",
      "args": ["mcp", "--vault", "/path/to/vault"]
    }
  }
}
```

## Encrypted sync

Vault contents stay plain Markdown on disk; when you need to move a vault
through a third-party channel (iCloud, Dropbox, git, email), export it
encrypted:

```bash
export RETEX_PASS='your passphrase'
retex export --vault ~/Vaults/CRM --out crm.retex --passphrase-env RETEX_PASS
# sync crm.retex anywhere, then:
retex import --from crm.retex --into ~/Vaults/CRM-restored --passphrase-env RETEX_PASS
```

The export is a single `RETEXENC1` file: PBKDF2-HMAC-SHA256 (600k iterations)
key derivation and AES-GCM authenticated encryption via Apple CryptoKit. The
passphrase is read from an environment variable or an interactive prompt —
never a command-line argument, so it never leaks through process listings.

## Updates

```bash
retex update
```

Checks the latest GitHub release, verifies the SHA-256 checksum of the
release archive before installing, swaps the binary atomically, and keeps the
previous binary at `<path>/retex.previous` for manual rollback. A failed
download, checksum mismatch, or bad archive leaves your current binary
untouched.

## Vault format

A Retex vault is just a folder of Markdown files — no app, account, or
credential is ever required to read or write one:

```
MyVault/
├── Deals/acme-redesign.md     # plain Markdown + YAML front matter
├── Contacts/jamie-doe.md
└── .retex/                    # optional internal state
    ├── config.json            # custom columns / saved views
    └── history.jsonl          # undo journal
```

Every file outside `.retex/` is ordinary Markdown readable in any editor.
Everything inside `.retex/` is derived state: delete the folder and Retex
rebuilds it on demand. The full contract is documented above and versioned
through `retex schema`.

## Data API (Markdown contract)

Retex reads ordinary Markdown files. YAML front matter describes each record
as a note, contact, deal, task, or agent-run. The parser supports flat
properties and inline lists; note bodies remain intact, including wiki links
and Markdown checklists.

```markdown
---
title: Acme website rebuild
type: deal
status: Proposal
rank: 1
owner: Retex Team
value: $11500
due: 2026-08-06
next_action: Send revised scope
tags: [website, priority]
archived: false
---

# Acme website rebuild

Linked contact: [[Jamie Doe]]

- [x] Draft agreement
- [ ] Send revised scope
```

Retex preserves the note body and unknown YAML properties. Board moves update
`status` and `rank`. Archiving writes `archived: true`; it does not delete the
file.

## Architecture

- `RetexCore` owns parsing, mutations, watching, crypto, the MCP server, and
  the update channel. It is a plain Swift package usable from any app.
- `RetexCLI` is the human and agent surface over `RetexCore`.
- Markdown remains authoritative; internal state lives under `<vault>/.retex/`
  and is always safe to delete (it is rebuilt on demand).
- A vault reader UI is planned as a separate product consuming `RetexCore`.

## Project status

Implemented today:

- Multi-vault navigation, search, atomic editing with unknown-property
  preservation
- Kanban boards with custom columns, saved views, and non-destructive
  archiving
- Undo history with cross-process journal locking
- FSEvents-based file watching that ignores internal state
- Vault health checks (`retex doctor`)
- An MCP server exposing the vault to any MCP host
- Encrypted export/import (PBKDF2 + AES-GCM)
- Self-update with checksum verification, atomic swap, and rollback
- Versioned JSON envelope on every CLI response
- 46 XCTests covering parsing, mutations, the CLI contract, undo, config,
  watching, crypto, update logic, and the MCP server

Not yet shipped:

- Apple notarization of release binaries (binaries are Developer ID–signed;
  notarization lands as soon as App Store Connect credentials are stored —
  see the release script)
- A vault reader UI (planned separate product)
- A disposable full-text index for very large vaults (plain scans stay fast)
- Optional encrypted sync server

## Contributing

Bug reports and focused pull requests are welcome on
[GitHub](https://github.com/michael-berardi/retex). Keep Markdown as the
source of truth, avoid committing private vault data or credentials, and
include documentation updates when a user-facing command or record property
changes.

## Security

Report vulnerabilities privately via GitHub Security Advisories rather than
public issues. Release assets are Developer ID–signed and checksummed; verify
the `SHA256SUMS` file before installing.

## License

Retex is released under the [MIT License](LICENSE).
